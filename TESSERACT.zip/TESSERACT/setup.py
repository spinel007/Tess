from setuptools import setup, find_packages

setup(
    name="pentestai",
    version="0.1.0",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    install_requires=[
        "requests>=2.28.0",
        "argparse>=1.4.0",
        "fastapi>=0.68.0",
        "uvicorn>=0.15.0",
        "click>=8.0.0",
        "rich>=10.0.0",
        "pydantic>=1.8.0",
        "python-gnupg>=0.5.0",
        "zstandard>=0.17.0",
        "rapidfuzz>=2.0.0",
        "elasticsearch>=7.0.0",
        "weasyprint>=54.0",
        "jinja2>=3.0.0",
        "pandas>=1.3.0"
    ],
    entry_points={
        'console_scripts': [
            'pentestai=pentestai.main:main',
        ],
    },
    python_requires=">=3.8",
) 